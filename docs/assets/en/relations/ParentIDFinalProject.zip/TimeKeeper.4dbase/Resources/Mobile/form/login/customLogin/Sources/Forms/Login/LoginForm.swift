//
//  LoginForm.swift
//  test
//
//  Created by Eric Marchand on Mon, 01 Jul 2019 14:59:30 GMT
//  ©2019 My Company All rights reserved

import UIKit
import QMobileUI

@IBDesignable
open class LoginForm: QMobileUI.LoginForm {

    @IBOutlet weak var passwordTextField: FloatingLabelTextField!

    // MARK: Event
    /// Called after the view has been loaded. Default does nothing
    open override func onLoad() {
    }
    /// Called when the view is about to made visible. Default does nothing
    open override func onWillAppear(_ animated: Bool) {
    }
    /// Called when the view has been fully transitioned onto the screen. Default does nothing
    open override func onDidAppear(_ animated: Bool) {
    }
    /// Called when the view is dismissed, covered or otherwise hidden. Default does nothing
    open override func onWillDisappear(_ animated: Bool) {
    }
    /// Called after the view was dismissed, covered or otherwise hidden. Default does nothing
    open override func onDidDisappear(_ animated: Bool) {
    }

    open override var customParameters: [String : Any]? {
        guard let text = passwordTextField.text else { return nil }
        return ["password": encrypt(text)]
    }

    func encrypt(_ password: String) -> String {
        return password // please encrypt it before sending it to server
    }
}
